<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class IplTransaction extends Model
{
    protected $fillable = [
        'resident_id', 'month', 'year', 'amount', 'status', 'paid_at', 'invoice_path',
    ];

    protected $casts = [
        'paid_at'   => 'datetime',
        'amount'    => 'decimal:2',
    ];

    // ── Relationships ──────────────────────────────────────────────────────

    public function resident(): BelongsTo
    {
        return $this->belongsTo(Resident::class);
    }

    // ── Accessors ─────────────────────────────────────────────────────────

    public function getMonthNameAttribute(): string
    {
        return Carbon::create()->month($this->month)->locale('id')->monthName;
    }

    public function getIsLunasAttribute(): bool
    {
        return $this->status === 'lunas';
    }

    public function getFormattedAmountAttribute(): string
    {
        return 'Rp ' . number_format($this->amount, 0, ',', '.');
    }
}
