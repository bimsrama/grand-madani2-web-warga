<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Resident extends Model
{
    protected $fillable = [
        'block', 'number', 'owner_name', 'wa_number', 'is_active',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    // ── Relationships ──────────────────────────────────────────────────────

    public function iplTransactions(): HasMany
    {
        return $this->hasMany(IplTransaction::class);
    }

    public function cameras(): BelongsToMany
    {
        return $this->belongsToMany(Camera::class, 'camera_resident');
    }

    // ── Accessors ─────────────────────────────────────────────────────────

    /** "Blok A / No. 12 (Budi Santoso)" */
    public function getDisplayNameAttribute(): string
    {
        return "Blok {$this->block} / No. {$this->number} ({$this->owner_name})";
    }

    /** Short label for dropdown */
    public function getDropdownLabelAttribute(): string
    {
        return "Blok {$this->block} / No. {$this->number}";
    }

    /** The "password" is the last 4 digits of the WA number */
    public function getWaPasswordAttribute(): string
    {
        return substr($this->wa_number, -4);
    }

    public function checkPassword(string $input): bool
    {
        return $this->wa_password === $input;
    }
}
